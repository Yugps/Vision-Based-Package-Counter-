# package detection conveyer belt > 2024-04-07 4:10pm
https://universe.roboflow.com/computer-vision-kaomr/package-detection-conveyer-belt

Provided by a Roboflow user
License: CC BY 4.0

